from parsingModule.mainParsing import SmartAgentClient

agent = SmartAgentClient()