import time

print(time.ctime(time.time()))
print(time.ctime(time.time() + 2592000))